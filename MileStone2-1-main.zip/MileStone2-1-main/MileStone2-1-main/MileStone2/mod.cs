﻿using System;
using System.Collections.Generic;

namespace MileStone2
{
    internal class mod
    {
        internal IEnumerable<object> GetPets(int word)
        {
            throw new NotImplementedException();
        }
    }
}