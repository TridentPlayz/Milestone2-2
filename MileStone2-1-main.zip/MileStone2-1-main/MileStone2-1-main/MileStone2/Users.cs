﻿using System;

namespace MileStone2
{
    internal class Users
    {
        internal void InsertUser(string text1, string text2, string text3, string text4)
        {
            throw new NotImplementedException();
        }

        internal object GetUsers()
        {
            throw new NotImplementedException();
        }

        internal string DeleteData(string text)
        {
            throw new NotImplementedException();
        }
    }
}